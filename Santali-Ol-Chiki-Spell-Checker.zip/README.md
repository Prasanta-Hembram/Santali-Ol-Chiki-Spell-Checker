# Santali(Ol Chiki)-Spell-checker
Santali-Spell-checker checker add-on for Firefox. It checks for wrong spellings and puts a red line in case it is wrong and will suggest a better word if one is available. If you are interested in contributing or want to add more words, you are free to send a PR.

Wordlist Corps source: [Foundational Language Tech: Santali Wordlist. O Foundation. CC0 1.0. (2021)"](https://github.com/ofdn/Before-AI)